/*
 *   GIF2PCX.C:  GIF to PC Paintbrush file translator.
 *   AUTHOR:   Zheng QuanZhan, Peking Unviersity, 1993
 */
 
#include <stdio.h>
#include <dos.h>
#include <malloc.h>

#ifndef MK_FP
#define MK_FP(seg,ofs) ((char far *) \
      (((unsigned long)(seg) << 16) | (unsigned)(ofs)))
#endif

#pragma pack(1)

typedef  struct {
  char manufacturer;
  char version;
  char encoding;
  char bits_per_pixel;
  int xmin,ymin;
  int xmax,ymax;
  int hres;
  int vres;
  char palette[48];
  char reserved;
  char colour_planes;
  int bytes_per_line;
  int palette_type;
  char filler[58];
} PCXHEAD;

typedef struct tagGLOBAL{ 
 char  version[3];
 char  subversion[3];
 unsigned int   screen_width;
     unsigned int   screen_depth;
     unsigned char  GlobalFlag;
     unsigned char  BackgroundColor;
 unsigned char  zero;
}GLOBAL; 

typedef struct tagLOCAL{  
 unsigned char comma;
     unsigned int  Image_Top;
     unsigned int  Image_Left;
     unsigned int  Image_Width;
     unsigned int  Image_Depth;
     unsigned char LocalFlag;
}LOCAL;

unsigned width,depth;
int  BitsPerPixel;
char far *buffer;
char palette[768];

extern char far *farptr( char far *,long );
unsigned pixels2bytes( unsigned int n );

main(int argc,char **argv)
{
 if(argc < 3) {
  printf("Usage: GIF2PCX  giffile  pcxfile\n");
  return(1);
 }
 printf( "PCX2GIF  translate GIF to PC Paintbrush file.\n");
 printf( "Copyright(R) Zheng QuanZhan, 1992,12\n\n");
 printf( "Converting: %s ==> %s.\n",argv[1],argv[2] );

 LoadGifFile( argv[1] );
 SavePcxFile( argv[2] );

 printf("\nDone !"); 
}
  
LoadGifFile( char *giffile )
{
 FILE *fp;
 GLOBAL g;
 LOCAL  l;
 int ColorNum;
 unsigned interlaced,ImageStart;
 
 if( (fp=fopen(giffile,"rb")) == NULL ){
  printf("FILE %s open error.\n",giffile);
  exit(1);
 } 

     fseek( fp,0L,SEEK_SET);
 fread( (char *)&g,1,sizeof(GLOBAL),fp );

     if( strnicmp( g.version,"gif87a",6 ) )   {
  printf("FILE %s is an invalide GIF file.\n",giffile);
  exit( 1 );
 }

 BitsPerPixel = (g.GlobalFlag & 0x7) + 1;
 ColorNum = 1 << BitsPerPixel;
 
 if( fread( palette,1,3*ColorNum,fp ) != 3*ColorNum )
 {
  printf("FILE %s read palette error.\n",giffile);
  exit(1);
 }
 fread( (char *)&l,1,sizeof(LOCAL),fp );
 
 width = l.Image_Width;
 depth = l.Image_Depth; 
     interlaced = l.LocalFlag & 0x40;
 ImageStart = 23 + ColorNum * 3;
 
 if( (buffer = (char far *)halloc( (long)width*(long)(depth+2),
    sizeof(char) )) == NULL )
 {
  printf("No enough memory !\n");
  exit(1);
 }
 
 if( unlzw( fp,buffer,(long)ImageStart,width,depth,interlaced ) )
 {
  printf("Unpack %s fail !\n",giffile);
  hfree( buffer );
  exit(1);
 } 
 fclose( fp );
}

SavePcxFile( char *pcxfile )
{
 FILE *fp;
 
 if( (fp=fopen(pcxfile,"wb")) == NULL) 
 {
  printf("FILE %s create error.\n",pcxfile);
  hfree( (char _huge *)buffer );   
  exit(1);
 }
 WritePcxHeader( fp,palette );
 PackPcx( fp,buffer );
 if( BitsPerPixel > 4 )
 Write256Palette( fp,BitsPerPixel );
 fclose( fp );
 
 hfree( (char _huge *)buffer );
}
  
WritePcxHeader(FILE *fp,char *palette )
{
 PCXHEAD h;
 
 memset((char *)&h,0,sizeof(PCXHEAD));
 h.manufacturer = 0x0a;
 h.version = 5;
 h.encoding = 1;
 h.xmin = h.ymin = 0;
 h.xmax = width - 1;
 h.ymax = depth - 1;
 h.hres = h.vres = 0;
 h.palette_type = 1;
 
 if( BitsPerPixel < 5 ) {
  h.bits_per_pixel = 1;
  h.colour_planes = BitsPerPixel;
  h.bytes_per_line = pixels2bytes(width);
  memcpy(h.palette,palette,(1 << BitsPerPixel)*3);
 }
 else if (BitsPerPixel == 8) {
  h.bits_per_pixel = 8;
  h.colour_planes = 1;
  h.bytes_per_line = width;
 }
 else {
  h.bits_per_pixel = 8;
  h.colour_planes = 1;
  h.bytes_per_line = width;
 }
 fwrite( (char *)&h,1,sizeof(PCXHEAD),fp ); 
}

PackPcx( FILE *fp,char far *buffer )
{
 register int x,y;
 char b[1024];
 char mask;
 int  pl;
 unsigned bytes = pixels2bytes(width);
 char far *p;
 
 for( y=0;y<depth;y++ )
 {
  p = farptr( buffer,(long)y*(long)width );
  if( BitsPerPixel > 4 )
   WritePcxLine( p,width,fp );
  else{
   for(pl=0;pl<BitsPerPixel;++pl) 
   {
    mask = 1 << pl;
    memset(b,0,width);
    for(x=0;x<width;++x) 
    {
     if(p[x] & mask)
        b[(x >> 3)] |= (0x80 >> (x & 0x0007));
    }
    WritePcxLine(b,bytes,fp);
   }
  } 
 }
}
 
WritePcxLine( char far *p,int bytes,FILE *fp )
{
 unsigned int i=0,j=0,t=0;
 
 do{
  i = 0;
  while( (p[t+i] == p[t+i+1]) && ((t+i)<bytes) && (i<63) )
   ++ i;
  if( i > 0 ) 
  {
   fputc( i | 0xc0,fp );
   fputc( p[t],fp );
   t += i;
   j += 2;
  }
  else{
   if( (p[t] & 0xc0) == 0xc0 )
   {
    fputc( 0xc1,fp );
    ++ j;
   }
   fputc( p[t++],fp );
   ++ j;
  }
 } while( t<bytes );
 
 return( j );
}     

Write256Palette( FILE *fp,int bits )
{
 int x;
 
 switch( bits ) {
  case 8:
   fputc(12,fp);
   fwrite(palette,1,3*(1 << bits),fp);
   break;
  case 7:
   fputc(12,fp);
   for(x=0;x<2;++x) 
    fwrite(palette,1,3*(1 << bits),fp);
   break;
  case 6:
   fputc(12,fp);
   for(x=0;x<4;++x) 
    fwrite(palette,1,3*(1 << bits),fp);
   break;
  case 5:
   fputc(12,fp);
   for(x=0;x<8;++x) 
    fwrite(palette,1,3*(1 << bits),fp);
   break;  
  default:
   break;  
 }
}

unsigned pixels2bytes( unsigned int n )
{
 if( n & 0x0007 )
      return ( (n>>3)+1 );
     else
          return ( n>>3 );
}

static char far *farptr( char far *p,long l )
{
     unsigned int seg,off;
 
     seg = FP_SEG(p);
     off = FP_OFF(p);
     seg += (off/16);
     off &= 0x000f;
     off += (unsigned int)( l & 0x000fL);
     seg += ( l/16L );
     p = (char far *)MK_FP(seg,off);
     
 return( p );
}